@tool
extends Control

# UI Elements
var record_btn: Button
var stop_btn: Button
var play_btn: Button
var save_btn: Button

var file_name_input: LineEdit
var format_option: OptionButton
var mic_device_option: OptionButton

var pitch_slider: HSlider
var pitch_label: Label
var status_label: Label
var volume_bar: ProgressBar

# Audio System
var effect_capture: AudioEffectRecord
var effect_spectrum: AudioEffectSpectrumAnalyzerInstance
var recording: AudioStreamWAV
var audio_player: AudioStreamPlayer
var mic_player: AudioStreamPlayer
var is_recording: bool = false

func _enter_tree() -> void:
	set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	custom_minimum_size = Vector2(400, 300)
	_setup_ui()
	_ensure_audio_bus_setup()

func _process(_delta: float) -> void:
	if is_recording and effect_spectrum:
		var mag = effect_spectrum.get_magnitude_for_frequency_range(20, 20000).length()
		if volume_bar:
			volume_bar.value = clamp(mag * 3000.0, 0.0, 100.0)

func _setup_ui() -> void:
	for c in get_children():
		c.queue_free()

	var scroll = ScrollContainer.new()
	scroll.set_anchors_and_offsets_preset(PRESET_FULL_RECT)
	scroll.custom_minimum_size = Vector2(400, 300)
	add_child(scroll)

	var main_vbox = VBoxContainer.new()
	main_vbox.custom_minimum_size = Vector2(580, 420)
	main_vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(main_vbox)

	# --- Title & Status ---
	var title = Label.new()
	title.text = "🎙️ GODOT AUDIO STUDIO (LIVE MIC CAPTURE)"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	main_vbox.add_child(title)

	status_label = Label.new()
	status_label.text = "Status: Connected to Windows Microphone"
	status_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	main_vbox.add_child(status_label)

	main_vbox.add_child(HSeparator.new())

	# --- Microphone Device Selector ---
	var mic_hbox = HBoxContainer.new()
	main_vbox.add_child(mic_hbox)

	var mic_lbl = Label.new()
	mic_lbl.text = "Select Windows Mic: "
	mic_hbox.add_child(mic_lbl)

	mic_device_option = OptionButton.new()
	mic_device_option.custom_minimum_size = Vector2(320, 30)
	_populate_mic_devices()
	mic_device_option.item_selected.connect(_on_mic_device_selected)
	mic_hbox.add_child(mic_device_option)

	main_vbox.add_child(HSeparator.new())

	# --- Mic Wave Level Bar ---
	var wave_label = Label.new()
	wave_label.text = "Live Voice Input Level:"
	main_vbox.add_child(wave_label)

	volume_bar = ProgressBar.new()
	volume_bar.custom_minimum_size = Vector2(0, 25)
	main_vbox.add_child(volume_bar)

	main_vbox.add_child(HSeparator.new())

	# --- Buttons ---
	var grid = HBoxContainer.new()
	grid.alignment = BoxContainer.ALIGNMENT_CENTER
	main_vbox.add_child(grid)

	record_btn = Button.new()
	record_btn.text = "🔴 START RECORDING"
	record_btn.custom_minimum_size = Vector2(160, 40)
	record_btn.pressed.connect(_on_record_pressed)
	grid.add_child(record_btn)

	stop_btn = Button.new()
	stop_btn.text = "⏹️ STOP"
	stop_btn.disabled = true
	stop_btn.custom_minimum_size = Vector2(100, 40)
	stop_btn.pressed.connect(_on_stop_pressed)
	grid.add_child(stop_btn)

	play_btn = Button.new()
	play_btn.text = "▶️ PLAY RECORDED VOICE"
	play_btn.disabled = true
	play_btn.custom_minimum_size = Vector2(180, 40)
	play_btn.pressed.connect(_on_play_pressed)
	grid.add_child(play_btn)

	main_vbox.add_child(HSeparator.new())

	# --- Pitch Controls ---
	var pitch_hbox = HBoxContainer.new()
	main_vbox.add_child(pitch_hbox)

	var p_label = Label.new()
	p_label.text = "Voice Pitch (0.5 Deep - 2.0 Thin): "
	pitch_hbox.add_child(p_label)

	pitch_slider = HSlider.new()
	pitch_slider.min_value = 0.3
	pitch_slider.max_value = 2.5
	pitch_slider.step = 0.05
	pitch_slider.value = 1.0
	pitch_slider.custom_minimum_size = Vector2(130, 20)
	pitch_slider.value_changed.connect(func(val): pitch_label.text = str(val))
	pitch_hbox.add_child(pitch_slider)

	pitch_label = Label.new()
	pitch_label.text = "1.0"
	pitch_hbox.add_child(pitch_label)

	main_vbox.add_child(HSeparator.new())

	# --- Save Options ---
	var save_grid = HBoxContainer.new()
	save_grid.alignment = BoxContainer.ALIGNMENT_CENTER
	main_vbox.add_child(save_grid)

	var f_title = Label.new()
	f_title.text = "Save Name: res://"
	save_grid.add_child(f_title)

	file_name_input = LineEdit.new()
	file_name_input.text = "my_windows_mic_voice"
	file_name_input.custom_minimum_size = Vector2(160, 32)
	save_grid.add_child(file_name_input)

	format_option = OptionButton.new()
	format_option.add_item(".wav")
	format_option.add_item(".mp3")
	format_option.add_item(".ogg")
	save_grid.add_child(format_option)

	save_btn = Button.new()
	save_btn.text = "💾 SAVE AUDIO"
	save_btn.disabled = true
	save_btn.custom_minimum_size = Vector2(120, 32)
	save_btn.pressed.connect(_on_save_pressed)
	save_grid.add_child(save_btn)

func _populate_mic_devices() -> void:
	mic_device_option.clear()
	var devices = AudioServer.get_input_device_list()
	for dev in devices:
		mic_device_option.add_item(dev)
	
	var current_device = AudioServer.get_input_device()
	for i in range(devices.size()):
		if devices[i] == current_device:
			mic_device_option.select(i)
			break

func _on_mic_device_selected(index: int) -> void:
	var selected_device = mic_device_option.get_item_text(index)
	AudioServer.set_input_device(selected_device)
	status_label.text = "Status: Windows Mic Changed -> " + selected_device

func _ensure_audio_bus_setup() -> void:
	ProjectSettings.set_setting("audio/driver/enable_input", true)

	if not audio_player:
		audio_player = AudioStreamPlayer.new()
		add_child(audio_player)

	if not mic_player:
		mic_player = AudioStreamPlayer.new()
		var mic_stream = AudioStreamMicrophone.new()
		mic_player.stream = mic_stream
		mic_player.bus = "Record"
		add_child(mic_player)

	var bus_idx = AudioServer.get_bus_index("Record")
	if bus_idx == -1:
		AudioServer.add_bus()
		bus_idx = AudioServer.bus_count - 1
		AudioServer.set_bus_name(bus_idx, "Record")

	AudioServer.set_bus_mute(bus_idx, false)
	AudioServer.set_bus_volume_db(bus_idx, 0.0)
	AudioServer.set_bus_send(bus_idx, "Master")

	for i in range(AudioServer.get_bus_effect_count(bus_idx) - 1, -1, -1):
		AudioServer.remove_bus_effect(bus_idx, i)

	effect_capture = AudioEffectRecord.new()
	AudioServer.add_bus_effect(bus_idx, effect_capture)

	var spec_eff = AudioEffectSpectrumAnalyzer.new()
	AudioServer.add_bus_effect(bus_idx, spec_eff)

	effect_spectrum = AudioServer.get_bus_effect_instance(bus_idx, 1)

func _on_record_pressed() -> void:
	_ensure_audio_bus_setup()
	
	if mic_player and not mic_player.playing:
		mic_player.play()

	if effect_capture:
		effect_capture.set_recording_active(false)
		effect_capture.set_recording_active(true)
		is_recording = true
		record_btn.disabled = true
		stop_btn.disabled = false
		play_btn.disabled = true
		save_btn.disabled = true
		status_label.text = "Status: 🎙️ RECORDING LIVE MIC... Speak Now!"

func _on_stop_pressed() -> void:
	if effect_capture:
		recording = effect_capture.get_recording()
		effect_capture.set_recording_active(false)
		is_recording = false
		
		if mic_player:
			mic_player.stop()

		volume_bar.value = 0
		record_btn.disabled = false
		stop_btn.disabled = true
		
		if recording and recording.data.size() > 0:
			play_btn.disabled = false
			save_btn.disabled = false
			status_label.text = "Status: ⏹️ Recording Complete! Click 'PLAY RECORDED VOICE'."
		else:
			status_label.text = "Status: ⚠️ Windows Mic not capturing audio."

func _on_play_pressed() -> void:
	if recording and audio_player:
		audio_player.stream = recording
		audio_player.pitch_scale = pitch_slider.value
		audio_player.play()
		status_label.text = "Status: ▶️ Playing back recorded voice..."

func _on_save_pressed() -> void:
	if recording:
		var ext = format_option.get_item_text(format_option.selected)
		var file_path = "res://" + file_name_input.text + ext
		var err = recording.save_to_wav(file_path)
		
		if err == OK:
			status_label.text = "Status: 💾 Audio File Saved to " + file_path
			if Engine.is_editor_hint():
				EditorInterface.get_resource_filesystem().scan()
		else:
			status_label.text = "Status: ❌ Save Failed!"
